globalThis.__PYON_LOADER__ = {
    loaderName: "Bunny",
    loaderVersion: "0.8.1",
    hasThemeSupport: true,
    storedTheme: null,
    fontPatch: 2
} 