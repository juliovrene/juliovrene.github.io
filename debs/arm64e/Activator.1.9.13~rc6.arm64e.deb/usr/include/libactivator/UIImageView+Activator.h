#import <UIKit/UIKit.h>

@interface UIImageView (Activator)
@property (nonatomic, assign) BOOL activatorListenerImageIsThreaded;
@property (nonatomic, copy) NSString *activatorListenerName;
@end
