globalThis.__PYON_LOADER__ = {
    loaderName: "Revenge",
    loaderVersion: "2.0.1",
    hasThemeSupport: true,
    storedTheme: null,
    fontPatch: 2
} 
